
function handleMessage(request, sender, sendResponse) {
 //console.log("Message from the content script: " + request.command);
  //console.log(request);
  //console.log(sender);
  //console.log(sendResponse);
  
//  sendResponse({response: "Response from background script"});
  //console.log(document.getElementById("operationResults").style);
  document.getElementById("operationResults").style.display = "block";  //make it visible
  //$("#operationResults").css("display","block");  //make it visible

  //turns button presses into code run in the background
  switch (request.command){
    case "successes":
      var el = document.getElementById("successes");
      el.textContent = request.message;
      //$('#successes').text(request.message);  //all of a sudden the jquery breaks???
      break;
    case "failures":
      document.getElementById("failures").textContent = request.message;
      
      //$('#failures').text(request.message);
      break;

    case "moved":
      document.getElementById("moved").textContent = request.message;
      break;
    case "skipped":
    document.getElementById("skipped").textContent = request.message;
     // $('#skipped').text(request.message);
      break;
    case "deleted":
    document.getElementById("deleted").textContent = request.message;
      //$('#deleted').text(request.message);
      break;
    case "duplicates":
    document.getElementById("duplicates").textContent = request.message;
      //$('#duplicates').text(request.message);
      break;
    case "localBefore":
    document.getElementById("localBefore").textContent = request.message;
      //$('#localBefore').text(request.message);
      break;
    case "serverBefore":
    document.getElementById("serverBefore").textContent = request.message;
      //$('#serverBefore').text(request.message);
      break;
    case "localAfter":
    document.getElementById("localAfter").textContent = request.message;
      //$('#localAfter').text(request.message);
      break;
    case "serverAfter":
    document.getElementById("serverAfter").textContent = request.message;
      //$('#serverAfter').text(request.message);
      break;
    case "close":
      window.close();
      break;

  }

}





/////////////////////////////////////////////////////////////////////////////

document.getElementById("version").innerHTML = chrome.runtime.getManifest().version;  //set the version number in the popup

chrome.runtime.onMessage.addListener(handleMessage);
//var sending = chrome.runtime.sendMessage({command: "removeDuplicates"  });//remove duplicates every time window is opened.


//var browserName = getBrowserName();
var loginbutton = document.getElementById("login");
var optInbutton = document.getElementById("optIn");
var installbutton = document.getElementById("install");
var registerbutton = document.getElementById("register");
var updatebutton = document.getElementById("update");
var renamebutton = document.getElementById("rename");
var printtreebutton = document.getElementById("printtree");
var resendvalidationbutton = document.getElementById("resendvalidation");
var forgotpasswordbutton = document.getElementById("forgotpassword");
var logoutlink = document.getElementById("logout");
var forceValidate = document.getElementById("forceValidate");
var clearall = document.getElementById("clearall");

loginbutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "login"  });
}, false);

optInbutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "optIn"  });
}, false);

installbutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "install"  });
}, false);

registerbutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "register"  });
}, false);

updatebutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "update"  });
}, false);

renamebutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "renametest"  });
}, false);

printtreebutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "printtree"  });
}, false);

resendvalidationbutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "resendvalidation"  });
}, false);

forgotpasswordbutton.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "forgotpassword"  });
}, false);


logoutlink.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "logout"  });
}, false);

forceValidate.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "forceValidate"  });
}, false);

clearall.addEventListener("click", function() {
    var sending = chrome.runtime.sendMessage({command: "clearall"  });
}, false);